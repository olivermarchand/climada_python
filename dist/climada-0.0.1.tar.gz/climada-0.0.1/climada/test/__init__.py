"""
test init
"""
