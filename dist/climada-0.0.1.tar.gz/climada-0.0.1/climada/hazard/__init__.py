"""
init hazard
"""
from .centroids import *
from .base import *
from .tag import *
