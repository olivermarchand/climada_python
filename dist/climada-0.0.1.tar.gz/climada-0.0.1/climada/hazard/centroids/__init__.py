"""
init centroids
"""
from .base import *
